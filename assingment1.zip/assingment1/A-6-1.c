#include <stdio.h>

void main()
{
    int i, j;

    i = 2;
    j = 2;

    if (i % j == 0)
    {
        
    }
    
}